
var amount=prompt("enter for amount","amount");
var year=prompt("enter for year","years");
var interest=prompt("enter rate of interest","interest");

var simple=(amount*year*interest)/100;
document.write("simple interest is "+simple); 