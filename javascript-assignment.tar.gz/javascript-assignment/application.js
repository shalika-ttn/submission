function f1 ()
{ 

	return  new Date();
}
//document.getElementById("id1").innerHTML=Date();
